# frozen_string_literal: true

class CreateShoppingCarts < ActiveRecord::Migration[5.2]
  def change
    create_table :shopping_carts do |t|
      t.references :user

      t.timestamps
    end
  end
end
