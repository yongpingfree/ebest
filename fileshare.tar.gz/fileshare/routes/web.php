<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\FileDownloadController;

Route::get('/files/{file}/download', FileDownloadController::class)
    ->middleware('auth')
    ->name('files.download');
Route::get('/', function () {
    return view('welcome');
});
