<x-filament-panels::page>
    @php($listing = $this->getListing())

    <x-filament::section>
        <div style="margin-bottom:1rem;">
            <a href="#" wire:click.prevent="goTo('')">Home</a>
            @foreach ($listing['crumbs'] as $crumbPath => $name)
                / <a href="#" wire:click.prevent="goTo(@js($crumbPath))">{{ $name }}</a>
            @endforeach
        </div>

        @if (empty($listing['folders']) && empty($listing['files']))
            <p>No files available today.</p>
        @else
            <table style="width:100%; border-collapse:collapse;">
                <thead>
                    <tr style="text-align:left; border-bottom:1px solid #e5e7eb;">
                        <th style="padding:.5rem;">Name</th>
                        <th style="padding:.5rem;">Size</th>
                        <th style="padding:.5rem;">Available until</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($listing['folders'] as $folder)
                        <tr style="border-bottom:1px solid #f3f4f6;">
                            <td style="padding:.5rem;">
                                📁 <a href="#" wire:click.prevent="openFolder(@js($folder))">{{ $folder }}</a>
                            </td>
                            <td></td><td></td>
                        </tr>
                    @endforeach

                    @foreach ($listing['files'] as $file)
                        <tr style="border-bottom:1px solid #f3f4f6;">
                            <td style="padding:.5rem;">
                                📄 <a href="{{ route('files.download', $file) }}">{{ basename($file->path) }}</a>
                            </td>
                            <td style="padding:.5rem;">{{ number_format($file->size / 1024, 1) }} KB</td>
                            <td style="padding:.5rem;">{{ $file->published_expires_at->format('Y-m-d H:i:s') }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        @endif
    </x-filament::section>
</x-filament-panels::page>
