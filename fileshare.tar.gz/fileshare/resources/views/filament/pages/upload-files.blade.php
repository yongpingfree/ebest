<x-filament-panels::page>
    {{ $this->form }}

    <div style="margin-top: 1.5rem;">
        <x-filament::button
            wire:click="processUpload"
            wire:loading.attr="disabled"
	    wire:target="processUpload"
            icon="heroicon-o-arrow-up-tray"
        >
            Upload
        </x-filament::button>
    </div>
</x-filament-panels::page>
