<?php
return [
    'originals' => env('FILESHARE_ORIGINALS'),
'tmp' => env('FILESHARE_TMP', '/srv/fileshare/tmp'),
    'published' => env('FILESHARE_PUBLISHED'),
    'original_retention_hours' => (float) env('ORIGINAL_RETENTION_HOURS', 36),
    'python' => env('PDF_TRANSFORM_PYTHON'),
    'script' => env('PDF_TRANSFORM_SCRIPT'),
];
