<?php

namespace App\Filament\Pages;

use App\Services\FileIngestService;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Schemas\Concerns\InteractsWithSchemas;
use Filament\Schemas\Contracts\HasSchemas;
use Filament\Schemas\Schema;
use Illuminate\Support\Facades\Storage;

class UploadFiles extends Page implements HasSchemas
{
    use InteractsWithSchemas;

    // keep the generated line, e.g.:
    protected string $view = 'filament.pages.upload-files';

    protected static ?string $navigationLabel = 'Upload files';
    protected static ?int $navigationSort = 1;

    public ?array $data = [];

    public function mount(): void
    {
        $this->form->fill(['extract_zip' => true]);
    }

    public function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('folder')
                    ->label('Target folder (optional)')
                    ->placeholder('e.g. reports/finance')
                    ->helperText('Files are placed in this folder. Leave empty for the top level.'),
                FileUpload::make('files')
                    ->label('Files')
                    ->multiple()
                    ->required()
                    ->preserveFilenames()
                    ->disk('local')
                    ->directory('upload-staging')
                    ->maxSize(512000)        // KB
                    ->maxParallelUploads(4),
                Toggle::make('extract_zip')
                    ->label('Unpack .zip files and keep their folder structure'),
            ])
            ->statePath('data');
    }

    public function processUpload(FileIngestService $ingest): void
    {
	\Log::info('UploadFiles::upload called', ['data' => $this->data]);
        $data = $this->form->getState();
        $folder = trim($data['folder'] ?? '', '/');
        $count = 0;

        foreach ((array) $data['files'] as $stored) {
            $abs = Storage::disk('local')->path($stored);
            $name = basename($stored);

            try {
                if (! empty($data['extract_zip']) && str_ends_with(strtolower($name), '.zip')) {
                    $count += $ingest->ingestZip($abs, $folder);
                } else {
                    $ingest->ingestFile($abs, trim($folder . '/' . $name, '/'));
                    $count++;
                }
            } catch (\Throwable $e) {
                Notification::make()->title("Failed: {$name}")->body($e->getMessage())->danger()->send();
            } finally {
                Storage::disk('local')->delete($stored);
            }
        }

        $this->form->fill(['extract_zip' => true]);

        Notification::make()
            ->title("{$count} file(s) uploaded and queued for processing")
            ->success()
            ->send();
    }
}
